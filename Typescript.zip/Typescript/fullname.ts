

function fullName(fname:string,mname:string,lname:string){
  return `FirstName:${fname} MiddleName:${mname} LastName:${lname}`
};

console.log(fullName("Panchashil","M.","Wankhede"));