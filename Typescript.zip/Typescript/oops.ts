

// export class Person{
 class Person{
    // data-member 
    pname:string="Ajit";
   protected pcontact:number=88888;
    padddress:string="chennai";
    psingle:boolean=true;
   private paadharNumber:number=987654321;
// constructor
constructor(name:string,contact:number,address:string,single:boolean){
   this.pname = name;
   this.pcontact = contact;
   this.padddress = address;
   this.psingle = single;

}
  
    //member function
    personDetails(){
        console.log(`Name:${this.pname} Contact:${this.pcontact} Single:${this.psingle} Address:${this.padddress} Aadhar:${this.paadharNumber}`);
    }

}
// how to create object of class 
// let personObj = new Person("Prashant",99999,"Mumbai",true);
//    console.log(personObj.pname);
//    personObj.personDetails();

// let personObj1 = new Person("Vijay",7777,"Banglore",true);
//    personObj1.personDetails();

// let personObj2 = new Person("Suresh",5555,"Hydrabad",true);
//    personObj2.personDetails();

export default Person;