console.log("Good Afternoon You All");
// 1. number data type
var num1 = 100, num2 = 0.5, num3 = 123456;
console.log(num1, num2, num3);
