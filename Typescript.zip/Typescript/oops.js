"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// export class Person{
var Person = /** @class */ (function () {
    // constructor
    function Person(name, contact, address, single) {
        // data-member 
        this.pname = "Ajit";
        this.pcontact = 88888;
        this.padddress = "chennai";
        this.psingle = true;
        this.paadharNumber = 987654321;
        this.pname = name;
        this.pcontact = contact;
        this.padddress = address;
        this.psingle = single;
    }
    //member function
    Person.prototype.personDetails = function () {
        console.log("Name:".concat(this.pname, " Contact:").concat(this.pcontact, " Single:").concat(this.psingle, " Address:").concat(this.padddress));
    };
    return Person;
}());
// how to create object of class 
// let personObj = new Person("Prashant",99999,"Mumbai",true);
//    console.log(personObj.pname);
//    personObj.personDetails();
// let personObj1 = new Person("Vijay",7777,"Banglore",true);
//    personObj1.personDetails();
// let personObj2 = new Person("Suresh",5555,"Hydrabad",true);
//    personObj2.personDetails();
exports.default = Person;
