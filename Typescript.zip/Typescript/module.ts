// import { Person } from "./oops"; 
import Person from "./oops";

let personObj2 = new Person("Suresh",5555,"Hydrabad",true);
    personObj2.personDetails();