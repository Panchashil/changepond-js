"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import { Person } from "./oops"; 
var oops_1 = require("./oops");
var personObj2 = new oops_1.default("Suresh", 5555, "Hydrabad", true);
personObj2.personDetails();
