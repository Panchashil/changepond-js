function fullName(fname, mname, lname) {
    return "FirstName:".concat(fname, " MiddleName:").concat(mname, " LastName:").concat(lname);
}
;
console.log(fullName("Panchashil", "M.", "Wankhede"));
